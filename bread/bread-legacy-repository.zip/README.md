# Bread · Legacy

Jinseok & Lucas

The 27 earlier designs: ten threads, seven comms templates and ten buds.

[Forum masterpost](forum-posts/bread-legacy-forum-masterpost.txt) · [Browser preview with Copy buttons](forum-posts/bread-legacy-preview.html)

Paste the masterpost into the forum editor to display each example above its copyable code. For an individual template, open a file below and copy its entire `[dohtml]` block. Download the browser preview and open it locally for rendered examples and Copy buttons.

Examples retain full sample writing. Posting snippets use `[TEXT GOES HERE]` or `[MESSAGE GOES HERE]`. Names, links, titles and GIFs remain editable.

| Design | Type | Posting snippet |
| --- | --- | --- |
| Hearthbound | thread | [bread-hearthbound-thread-03.txt](bread/bread-hearthbound-thread-03.txt) |
| Levain Letters | thread | [bread-levain-letters-thread-02.txt](bread/bread-levain-letters-thread-02.txt) |
| Pain de Papier | thread | [bread-pain-de-papier-thread-01.txt](bread/bread-pain-de-papier-thread-01.txt) |
| Sunday Crust | thread | [bread-sunday-crust-thread-05.txt](bread/bread-sunday-crust-thread-05.txt) |
| The Proofing Room | thread | [bread-the-proofing-room-thread-04.txt](bread/bread-the-proofing-room-thread-04.txt) |
| Standard | thread | [bread-standard-thread.txt](bread/bread-standard-thread.txt) |
| Single Gif | thread | [bread-single-gif-thread.txt](bread/bread-single-gif-thread.txt) |
| Rounded | thread | [bread-rounded-thread.txt](bread/bread-rounded-thread.txt) |
| Scroll | thread | [bread-scroll-thread.txt](bread/bread-scroll-thread.txt) |
| Split | thread | [bread-split-thread.txt](bread/bread-split-thread.txt) |
| Batch Chat | comms | [bread-batch-chat-comms-03.txt](bread/bread-batch-chat-comms-03.txt) |
| Butterwire | comms | [bread-butterwire-comms-04.txt](bread/bread-butterwire-comms-04.txt) |
| Sent | comms | [bread-sent-comms.txt](bread/bread-sent-comms.txt) |
| Received | comms | [bread-received-comms.txt](bread/bread-received-comms.txt) |
| Crumbline | comms | [bread-crumbline-comms-01.txt](bread/bread-crumbline-comms-01.txt) |
| Daily Knead | comms | [bread-daily-knead-comms-05.txt](bread/bread-daily-knead-comms-05.txt) |
| Toast Talk | comms | [bread-toast-talk-comms-02.txt](bread/bread-toast-talk-comms-02.txt) |
| Standard | bud | [bread-standard-bud.txt](bread/bread-standard-bud.txt) |
| Portrait | bud | [bread-portrait-bud.txt](bread/bread-portrait-bud.txt) |
| Duo | bud | [bread-duo-bud.txt](bread/bread-duo-bud.txt) |
| Minimal | bud | [bread-minimal-bud.txt](bread/bread-minimal-bud.txt) |
| Strip | bud | [bread-strip-bud.txt](bread/bread-strip-bud.txt) |
| Crustlet | bud | [bread-crustlet-bud-03.txt](bread/bread-crustlet-bud-03.txt) |
| Petit Pain | bud | [bread-petit-pain-bud-01.txt](bread/bread-petit-pain-bud-01.txt) |
| Pocket Roll | bud | [bread-pocket-roll-bud-05.txt](bread/bread-pocket-roll-bud-05.txt) |
| Rye Note | bud | [bread-rye-note-bud-04.txt](bread/bread-rye-note-bud-04.txt) |
| Sesame Kiss | bud | [bread-sesame-kiss-bud-02.txt](bread/bread-sesame-kiss-bud-02.txt) |

## Hosted styling

The included stylesheets are copies of this set’s dependencies. Forum snippets keep their existing published stylesheet URLs in `lexdoescodingnow/templates`, so moving these files does not break existing posts. GIFs and optional fonts also require internet access. Member colours and forum light/dark modes are unchanged.

## Repository contents

`bread/` contains only this generation’s individual posting snippets and supporting CSS. `forum-posts/` contains its masterpost, numbered parts and browser preview. `designs.json` lists the included designs.
