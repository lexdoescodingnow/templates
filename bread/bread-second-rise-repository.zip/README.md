# Bread · Second Rise

Jinseok & Lucas

The 15 newer designs for current forum use: five threads, five comms and five buds.

[Forum masterpost](forum-posts/bread-forum-masterpost.txt) · [Browser preview with Copy buttons](forum-posts/bread-preview.html)

Paste the masterpost into the forum editor to display each example above its copyable code. For an individual template, open a file below and copy its entire `[dohtml]` block. Download the browser preview and open it locally for rendered examples and Copy buttons.

Examples retain full sample writing. Posting snippets use `[TEXT GOES HERE]` or `[MESSAGE GOES HERE]`. Names, links, titles and GIFs remain editable.

| Design | Type | Posting snippet |
| --- | --- | --- |
| Baker’s Measure | thread | [bread-bakers-measure-thread-05.txt](bread/bread-bakers-measure-thread-05.txt) |
| Crumb Structure | thread | [bread-crumb-structure-thread-01.txt](bread/bread-crumb-structure-thread-01.txt) |
| Fougasse Folio | thread | [bread-fougasse-folio-thread-04.txt](bread/bread-fougasse-folio-thread-04.txt) |
| Plaited Vows | thread | [bread-plaited-vows-thread-03.txt](bread/bread-plaited-vows-thread-03.txt) |
| Pullman Nocturne | thread | [bread-pullman-nocturne-thread-02.txt](bread/bread-pullman-nocturne-thread-02.txt) |
| Brioche Buffer | comms | [bread-brioche-buffer-comms-04.txt](bread/bread-brioche-buffer-comms-04.txt) |
| Crust Signal | comms | [bread-crust-signal-comms-01.txt](bread/bread-crust-signal-comms-01.txt) |
| Loafline | comms | [bread-loafline-comms-02.txt](bread/bread-loafline-comms-02.txt) |
| Starter Sync | comms | [bread-starter-sync-comms-03.txt](bread/bread-starter-sync-comms-03.txt) |
| Toastwave | comms | [bread-toastwave-comms-05.txt](bread/bread-toastwave-comms-05.txt) |
| Croûton | bud | [bread-crouton-bud-01.txt](bread/bread-crouton-bud-01.txt) |
| Heel & Heart | bud | [bread-heel-and-heart-bud-04.txt](bread/bread-heel-and-heart-bud-04.txt) |
| Last Morsel | bud | [bread-last-morsel-bud-05.txt](bread/bread-last-morsel-bud-05.txt) |
| Little Plait | bud | [bread-little-plait-bud-03.txt](bread/bread-little-plait-bud-03.txt) |
| Pinch of Rye | bud | [bread-pinch-of-rye-bud-02.txt](bread/bread-pinch-of-rye-bud-02.txt) |

## Hosted styling

The included stylesheets are copies of this set’s dependencies. Forum snippets keep their existing published stylesheet URLs in `lexdoescodingnow/templates`, so moving these files does not break existing posts. GIFs and optional fonts also require internet access. Member colours and forum light/dark modes are unchanged.

## Repository contents

`bread/` contains only this generation’s individual posting snippets and supporting CSS. `forum-posts/` contains its masterpost, numbered parts and browser preview. `designs.json` lists the included designs.
