# Macadamia · Legacy

Journey & Kai

The 11 earlier designs: five threads, one comms template and five buds.

[Forum masterpost](forum-posts/macadamia-legacy-forum-masterpost.txt) · [Browser preview with Copy buttons](forum-posts/macadamia-legacy-preview.html)

Paste the masterpost into the forum editor to display each example above its copyable code. For an individual template, open a file below and copy its entire `[dohtml]` block. Download the browser preview and open it locally for rendered examples and Copy buttons.

Examples retain full sample writing. Posting snippets use `[TEXT GOES HERE]` or `[MESSAGE GOES HERE]`. Names, links, titles and GIFs remain editable.

| Design | Type | Posting snippet |
| --- | --- | --- |
| Macadamia 01 · Kernel Archive | thread | [macadamia-kernel-archive-thread.txt](macadamia/macadamia-kernel-archive-thread.txt) |
| Macadamia 02 · Soft Shell | thread | [macadamia-soft-shell-thread.txt](macadamia/macadamia-soft-shell-thread.txt) |
| Macadamia 03 · Scroll Archive | thread | [macadamia-scroll-archive-thread.txt](macadamia/macadamia-scroll-archive-thread.txt) |
| Macadamia 04 · Single Serve | thread | [macadamia-single-serve-thread.txt](macadamia/macadamia-single-serve-thread.txt) |
| Macadamia 05 · Contact Sheet | thread | [macadamia-contact-sheet-thread.txt](macadamia/macadamia-contact-sheet-thread.txt) |
| Shellphone | comms | [macadamia-comms-snippet.txt](macadamia/macadamia-comms-snippet.txt) |
| Macadamia Bud 01 · Sprout | bud | [macadamia-sprout-bud.txt](macadamia/macadamia-sprout-bud.txt) |
| Macadamia Bud 02 · Stemline | bud | [macadamia-stemline-bud.txt](macadamia/macadamia-stemline-bud.txt) |
| Macadamia Bud 03 · Pocket Bud | bud | [macadamia-pocket-bud-bud.txt](macadamia/macadamia-pocket-bud-bud.txt) |
| Macadamia Bud 04 · Pressed Leaf | bud | [macadamia-pressed-leaf-bud.txt](macadamia/macadamia-pressed-leaf-bud.txt) |
| Macadamia Bud 05 · Twin Bud | bud | [macadamia-twin-bud-bud.txt](macadamia/macadamia-twin-bud-bud.txt) |

## Hosted styling

The included stylesheets are copies of this set’s dependencies. Forum snippets keep their existing published stylesheet URLs in `lexdoescodingnow/templates`, so moving these files does not break existing posts. GIFs and optional fonts also require internet access. Member colours and forum light/dark modes are unchanged.

## Repository contents

`macadamia/` contains only this generation’s individual posting snippets and supporting CSS. `forum-posts/` contains its masterpost, numbered parts and browser preview. `designs.json` lists the included designs.
