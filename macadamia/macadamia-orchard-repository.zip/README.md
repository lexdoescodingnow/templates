# Macadamia · Orchard

Journey & Kai

The 15 newer designs for current forum use: five threads, five comms and five buds.

[Forum masterpost](forum-posts/macadamia-forum-masterpost.txt) · [Browser preview with Copy buttons](forum-posts/macadamia-preview.html)

Paste the masterpost into the forum editor to display each example above its copyable code. For an individual template, open a file below and copy its entire `[dohtml]` block. Download the browser preview and open it locally for rendered examples and Copy buttons.

Examples retain full sample writing. Posting snippets use `[TEXT GOES HERE]` or `[MESSAGE GOES HERE]`. Names, links, titles and GIFs remain editable.

| Design | Type | Posting snippet |
| --- | --- | --- |
| Hilum Press | thread | [macadamia-hilum-press-thread-03.txt](macadamia/macadamia-hilum-press-thread-03.txt) |
| Orchard Weave | thread | [macadamia-orchard-weave-thread-05.txt](macadamia/macadamia-orchard-weave-thread-05.txt) |
| Raceme Letters | thread | [macadamia-raceme-letters-thread-01.txt](macadamia/macadamia-raceme-letters-thread-01.txt) |
| Terrazzo Milk | thread | [macadamia-terrazzo-milk-thread-02.txt](macadamia/macadamia-terrazzo-milk-thread-02.txt) |
| Whorl House | thread | [macadamia-whorl-house-thread-04.txt](macadamia/macadamia-whorl-house-thread-04.txt) |
| Milkglass Duo | comms | [macadamia-milkglass-duo-comms-02.txt](macadamia/macadamia-milkglass-duo-comms-02.txt) |
| Orchard Pocket | comms | [macadamia-orchard-pocket-comms-04.txt](macadamia/macadamia-orchard-pocket-comms-04.txt) |
| Raceme Mobile | comms | [macadamia-raceme-mobile-comms-01.txt](macadamia/macadamia-raceme-mobile-comms-01.txt) |
| Roast Terminal | comms | [macadamia-roast-terminal-comms-03.txt](macadamia/macadamia-roast-terminal-comms-03.txt) |
| Whisper Kernel | comms | [macadamia-whisper-kernel-comms-05.txt](macadamia/macadamia-whisper-kernel-comms-05.txt) |
| Blossom Pair | bud | [macadamia-blossom-pair-bud-03.txt](macadamia/macadamia-blossom-pair-bud-03.txt) |
| Butterfleck | bud | [macadamia-butterfleck-bud-02.txt](macadamia/macadamia-butterfleck-bud-02.txt) |
| Crumbprint | bud | [macadamia-crumbprint-bud-04.txt](macadamia/macadamia-crumbprint-bud-04.txt) |
| Hilum | bud | [macadamia-hilum-bud-01.txt](macadamia/macadamia-hilum-bud-01.txt) |
| Whorllet | bud | [macadamia-whorllet-bud-05.txt](macadamia/macadamia-whorllet-bud-05.txt) |

## Hosted styling

The included stylesheets are copies of this set’s dependencies. Forum snippets keep their existing published stylesheet URLs in `lexdoescodingnow/templates`, so moving these files does not break existing posts. GIFs and optional fonts also require internet access. Member colours and forum light/dark modes are unchanged.

## Repository contents

`macadamia/` contains only this generation’s individual posting snippets and supporting CSS. `forum-posts/` contains its masterpost, numbered parts and browser preview. `designs.json` lists the included designs.
