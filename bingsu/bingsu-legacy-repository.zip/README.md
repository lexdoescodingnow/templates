# Bingsu · Legacy

Isaiah & Max

The 11 earlier designs: five threads, one comms template and five buds.

[Forum masterpost](forum-posts/bingsu-legacy-forum-masterpost.txt) · [Browser preview with Copy buttons](forum-posts/bingsu-legacy-preview.html)

Paste the masterpost into the forum editor to display each example above its copyable code. For an individual template, open a file below and copy its entire `[dohtml]` block. Download the browser preview and open it locally for rendered examples and Copy buttons.

Examples retain full sample writing. Posting snippets use `[TEXT GOES HERE]` or `[MESSAGE GOES HERE]`. Names, links, titles and GIFs remain editable.

| Design | Type | Posting snippet |
| --- | --- | --- |
| Variant 1 — Classic Twin | thread | [bingsu-classic-twin-thread.txt](bingsu/bingsu-classic-twin-thread.txt) |
| Variant 2 — Single Scoop | thread | [bingsu-single-scoop-thread.txt](bingsu/bingsu-single-scoop-thread.txt) |
| Variant 3 — Soft Scoop | thread | [bingsu-soft-scoop-thread.txt](bingsu/bingsu-soft-scoop-thread.txt) |
| Variant 4 — Snowglobe Scroll | thread | [bingsu-snowglobe-scroll-thread.txt](bingsu/bingsu-snowglobe-scroll-thread.txt) |
| Variant 5 — Layered Bowl | thread | [bingsu-layered-bowl-thread.txt](bingsu/bingsu-layered-bowl-thread.txt) |
| Comms Snippet | comms | [bingsu-comms-snippet-comms.txt](bingsu/bingsu-comms-snippet-comms.txt) |
| Variant 1 — Snowcap | bud | [bingsu-snowcap-bud.txt](bingsu/bingsu-snowcap-bud.txt) |
| Variant 2 — Sprig | bud | [bingsu-sprig-bud.txt](bingsu/bingsu-sprig-bud.txt) |
| Variant 3 — Dewdrop | bud | [bingsu-dewdrop-bud.txt](bingsu/bingsu-dewdrop-bud.txt) |
| Variant 4 — Duet | bud | [bingsu-duet-bud.txt](bingsu/bingsu-duet-bud.txt) |
| Variant 5 — Quick Note | bud | [bingsu-quick-note-bud.txt](bingsu/bingsu-quick-note-bud.txt) |

## Hosted styling

The included stylesheets are copies of this set’s dependencies. Forum snippets keep their existing published stylesheet URLs in `lexdoescodingnow/templates`, so moving these files does not break existing posts. GIFs and optional fonts also require internet access. Member colours and forum light/dark modes are unchanged.

## Repository contents

`bingsu/` contains only this generation’s individual posting snippets and supporting CSS. `forum-posts/` contains its masterpost, numbered parts and browser preview. `designs.json` lists the included designs.
