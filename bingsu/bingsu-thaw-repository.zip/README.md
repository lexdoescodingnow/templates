# Bingsu · Thaw

Isaiah & Max

The 15 newer designs for current forum use: five threads, five comms and five buds.

[Forum masterpost](forum-posts/bingsu-forum-masterpost.txt) · [Browser preview with Copy buttons](forum-posts/bingsu-preview.html)

Paste the masterpost into the forum editor to display each example above its copyable code. For an individual template, open a file below and copy its entire `[dohtml]` block. Download the browser preview and open it locally for rendered examples and Copy buttons.

Examples retain full sample writing. Posting snippets use `[TEXT GOES HERE]` or `[MESSAGE GOES HERE]`. Names, links, titles and GIFs remain editable.

| Design | Type | Posting snippet |
| --- | --- | --- |
| Crystal Veil | thread | [bingsu-crystal-veil-thread-02.txt](bingsu/bingsu-crystal-veil-thread-02.txt) |
| First Thaw | thread | [bingsu-first-thaw-thread-04.txt](bingsu/bingsu-first-thaw-thread-04.txt) |
| Meltwater Letters | thread | [bingsu-meltwater-letters-thread-03.txt](bingsu/bingsu-meltwater-letters-thread-03.txt) |
| Rime Reverie | thread | [bingsu-rime-reverie-thread-01.txt](bingsu/bingsu-rime-reverie-thread-01.txt) |
| Snowlight Sonata | thread | [bingsu-snowlight-sonata-thread-05.txt](bingsu/bingsu-snowlight-sonata-thread-05.txt) |
| Berry Byte | comms | [bingsu-berry-byte-comms-05.txt](bingsu/bingsu-berry-byte-comms-05.txt) |
| Frostline | comms | [bingsu-frostline-comms-01.txt](bingsu/bingsu-frostline-comms-01.txt) |
| Glacé Chat | comms | [bingsu-glace-chat-comms-02.txt](bingsu/bingsu-glace-chat-comms-02.txt) |
| Sleet Signal | comms | [bingsu-sleet-signal-comms-04.txt](bingsu/bingsu-sleet-signal-comms-04.txt) |
| Snowglow | comms | [bingsu-snowglow-comms-03.txt](bingsu/bingsu-snowglow-comms-03.txt) |
| Frostpetal | bud | [bingsu-frostpetal-bud-03.txt](bingsu/bingsu-frostpetal-bud-03.txt) |
| Icelet | bud | [bingsu-icelet-bud-01.txt](bingsu/bingsu-icelet-bud-01.txt) |
| Last Snow | bud | [bingsu-last-snow-bud-05.txt](bingsu/bingsu-last-snow-bud-05.txt) |
| Milky Kiss | bud | [bingsu-milky-kiss-bud-02.txt](bingsu/bingsu-milky-kiss-bud-02.txt) |
| Syrup Trace | bud | [bingsu-syrup-trace-bud-04.txt](bingsu/bingsu-syrup-trace-bud-04.txt) |

## Hosted styling

The included stylesheets are copies of this set’s dependencies. Forum snippets keep their existing published stylesheet URLs in `lexdoescodingnow/templates`, so moving these files does not break existing posts. GIFs and optional fonts also require internet access. Member colours and forum light/dark modes are unchanged.

## Repository contents

`bingsu/` contains only this generation’s individual posting snippets and supporting CSS. `forum-posts/` contains its masterpost, numbered parts and browser preview. `designs.json` lists the included designs.

For an existing post that displays without its styling, add the complete [stylesheet repair block](bingsu/bingsu-thaw-stylesheet-repair.txt) once at the end of the post. The current snippets already include this direct stylesheet link.
