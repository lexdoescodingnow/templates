BLUE HOUR CHARACTER LIBRARY

Open index.html to browse all 181 characters.
Open posts/<character>.txt and copy the complete contents into Blue Hour.
Previews use the shared assets folder; keep it beside the previews folder.
Photos, Spotify and maps need an internet connection.
Import library.json in the character atelier to edit these records.
Review migration-coverage.html for the available sources and known gaps.
