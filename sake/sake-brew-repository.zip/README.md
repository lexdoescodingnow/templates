# Sake · Brew

Jett & Miles

The 15 newer designs for current forum use: five threads, five comms and five buds.

[Forum masterpost](forum-posts/sake-forum-masterpost.txt) · [Browser preview with Copy buttons](forum-posts/sake-preview.html)

Paste the masterpost into the forum editor to display each example above its copyable code. For an individual template, open a file below and copy its entire `[dohtml]` block. Download the browser preview and open it locally for rendered examples and Copy buttons.

Examples retain full sample writing. Posting snippets use `[TEXT GOES HERE]` or `[MESSAGE GOES HERE]`. Names, links, titles and GIFs remain editable.

| Design | Type | Posting snippet |
| --- | --- | --- |
| Ginjo Veil | thread | [sake-ginjo-veil-thread-05.txt](sake/sake-ginjo-veil-thread-05.txt) |
| Kikichoko Reverie | thread | [sake-kikichoko-reverie-thread-02.txt](sake/sake-kikichoko-reverie-thread-02.txt) |
| Koji Chronicle | thread | [sake-koji-chronicle-thread-01.txt](sake/sake-koji-chronicle-thread-01.txt) |
| Kurabito Ledger | thread | [sake-kurabito-ledger-thread-04.txt](sake/sake-kurabito-ledger-thread-04.txt) |
| Moromi Interval | thread | [sake-moromi-interval-thread-03.txt](sake/sake-moromi-interval-thread-03.txt) |
| Koji Key | comms | [sake-koji-key-comms-02.txt](sake/sake-koji-key-comms-02.txt) |
| Kura Dial | comms | [sake-kura-dial-comms-01.txt](sake/sake-kura-dial-comms-01.txt) |
| Masu Relay | comms | [sake-masu-relay-comms-03.txt](sake/sake-masu-relay-comms-03.txt) |
| Namazake Touch | comms | [sake-namazake-touch-comms-04.txt](sake/sake-namazake-touch-comms-04.txt) |
| Shizuku Signal | comms | [sake-shizuku-signal-comms-05.txt](sake/sake-shizuku-signal-comms-05.txt) |
| Kasumi Slip | bud | [sake-kasumi-slip-bud-03.txt](sake/sake-kasumi-slip-bud-03.txt) |
| Komelet | bud | [sake-komelet-bud-02.txt](sake/sake-komelet-bud-02.txt) |
| Ochoko | bud | [sake-ochoko-bud-01.txt](sake/sake-ochoko-bud-01.txt) |
| Renzoku | bud | [sake-renzoku-bud-05.txt](sake/sake-renzoku-bud-05.txt) |
| Tomezoe | bud | [sake-tomezoe-bud-04.txt](sake/sake-tomezoe-bud-04.txt) |

## Hosted styling

The included stylesheets are copies of this set’s dependencies. Forum snippets keep their existing published stylesheet URLs in `lexdoescodingnow/templates`, so moving these files does not break existing posts. GIFs and optional fonts also require internet access. Member colours and forum light/dark modes are unchanged.

## Repository contents

`sake/` contains only this generation’s individual posting snippets and supporting CSS. `forum-posts/` contains its masterpost, numbered parts and browser preview. `designs.json` lists the included designs.
