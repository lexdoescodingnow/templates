# Sake · Legacy

Jett & Miles

The 11 earlier designs: five threads, one comms template and five buds.

[Forum masterpost](forum-posts/sake-legacy-forum-masterpost.txt) · [Browser preview with Copy buttons](forum-posts/sake-legacy-preview.html)

Paste the masterpost into the forum editor to display each example above its copyable code. For an individual template, open a file below and copy its entire `[dohtml]` block. Download the browser preview and open it locally for rendered examples and Copy buttons.

Examples retain full sample writing. Posting snippets use `[TEXT GOES HERE]` or `[MESSAGE GOES HERE]`. Names, links, titles and GIFs remain editable.

| Design | Type | Posting snippet |
| --- | --- | --- |
| Standard · First Pour | thread | [sake-standard-first-pour-thread.txt](sake/sake-standard-first-pour-thread.txt) |
| Solo Pour · Single Gif | thread | [sake-solo-pour-single-gif-thread.txt](sake/sake-solo-pour-single-gif-thread.txt) |
| Round Cask · Soft Edges | thread | [sake-round-cask-soft-edges-thread.txt](sake/sake-round-cask-soft-edges-thread.txt) |
| Night Pour · Scrollbox | thread | [sake-night-pour-scrollbox-thread.txt](sake/sake-night-pour-scrollbox-thread.txt) |
| Tasting Flight · Offset Cards | thread | [sake-tasting-flight-offset-cards-thread.txt](sake/sake-tasting-flight-offset-cards-thread.txt) |
| Sakazuki Line | comms | [comms-snippet.txt](sake/comms-snippet.txt) |
| Portrait Window · Large Gif | bud | [sake-portrait-window-large-gif-bud.txt](sake/sake-portrait-window-large-gif-bud.txt) |
| Ochoko Bud · Round Cup | bud | [sake-ochoko-bud-round-cup-bud.txt](sake/sake-ochoko-bud-round-cup-bud.txt) |
| Tasting Bud · Two Gifs | bud | [sake-tasting-bud-two-gifs-bud.txt](sake/sake-tasting-bud-two-gifs-bud.txt) |
| Pressed Bud · Text Only | bud | [sake-pressed-bud-text-only-bud.txt](sake/sake-pressed-bud-text-only-bud.txt) |
| Quick Pour · Compact Scroll | bud | [sake-quick-pour-compact-scroll-bud.txt](sake/sake-quick-pour-compact-scroll-bud.txt) |

## Hosted styling

The included stylesheets are copies of this set’s dependencies. Forum snippets keep their existing published stylesheet URLs in `lexdoescodingnow/templates`, so moving these files does not break existing posts. GIFs and optional fonts also require internet access. Member colours and forum light/dark modes are unchanged.

## Repository contents

`sake/` contains only this generation’s individual posting snippets and supporting CSS. `forum-posts/` contains its masterpost, numbered parts and browser preview. `designs.json` lists the included designs.
