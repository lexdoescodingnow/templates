const fs=require('fs');
const path=require('path');
const {SULTANA_DESIGNS,sulDefault,sulSnippet,sulFilename}=require('./sultana-editor.js');
const root=__dirname;
for(const d of SULTANA_DESIGNS)fs.writeFileSync(path.join(root,sulFilename(d)),sulSnippet(d,sulDefault(d)));
const css=fs.readFileSync(path.join(root,'sultana-collection-v1.css'),'utf8');
const ui=fs.readFileSync(path.join(root,'sultana-preview.css'),'utf8');
const script=fs.readFileSync(path.join(root,'sultana-editor.js'),'utf8');
const html=`<!doctype html>
<html lang="en" color-mode="light">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Sultana · Fifteen JCink Templates</title>
<style id="collection-css">${css}</style>
<style>${ui}</style>
</head>
<body>
<header class="cover">
<div class="cover-line"><a href="https://github.com/lexdoescodingnow/templates/tree/main/sultana">Lex's template collection / Sultana</a><span>Threads · Comms · Buds</span></div>
<div class="cover-title"><h1>Sultana</h1><svg viewBox="0 0 100 100" aria-hidden="true"><path d="M46 36Q58 12 75 5M53 24Q28 25 31 8Q46 7 53 24ZM58 18c20 8 29-3 22-8M37 43q-7 9-2 14m20-20q-6 7-3 11m16-2q-6 8-2 12m-19 2q-6 7-1 12m11 3q-4 6-1 10"/><ellipse cx="34" cy="49" rx="11" ry="15" transform="rotate(25 34 49)"/><ellipse cx="54" cy="40" rx="10" ry="13" transform="rotate(-14 54 40)"/><ellipse cx="69" cy="51" rx="10" ry="14" transform="rotate(24 69 51)"/><ellipse cx="45" cy="67" rx="10" ry="14" transform="rotate(-15 45 67)"/><ellipse cx="61" cy="71" rx="9" ry="12" transform="rotate(24 61 71)"/><ellipse cx="53" cy="86" rx="8" ry="10" transform="rotate(-8 53 86)"/></svg><p>Some sweetness lingers.<br>Fifteen intimate frames for stories ripened by time. Coloured by you.</p></div>
<div class="cover-bottom"><span>05 threads · 05 electronic comms · 05 miniature buds</span><button type="button" id="overview-button" aria-expanded="false" aria-controls="overview">View all 15 designs</button></div>
</header>
<section class="overview" id="overview" hidden>
<div class="overview-heading"><h2>The whole collection</h2><label>Show<select id="gallery-filter"><option value="all">All 15 designs</option><option value="thread">Five threads</option><option value="comms">Five comms</option><option value="bud">Five buds</option></select></label></div><div class="gallery-grid" id="gallery-grid"></div>
</section>
<main class="workspace" id="editor-anchor">
<nav class="design-menu" aria-label="Sultana designs">
<p class="menu-title">Choose your design</p>
<section class="menu-group"><h2>Threads <small>01–05</small></h2><div id="menu-thread"></div></section>
<section class="menu-group"><h2>Comms <small>01–05</small></h2><div id="menu-comms"></div></section>
<section class="menu-group"><h2>Buds <small>01–05</small></h2><div id="menu-bud"></div></section>
<div class="menu-footer"><a href="https://github.com/lexdoescodingnow/templates/blob/main/sultana/README.md">Collection &amp; posting guide ↗</a></div>
</nav>
<section class="workbench">
<div class="controls">
<label>Design<select id="design-select"></select></label>
<label>Colour sample<select id="palette-select"><option value="vintage">Vintage</option><option value="orchid">Orchid</option><option value="grove">Grove</option></select></label>
<label>Mode<select id="mode-select"><option value="light">Light</option><option value="dark">Dark</option><option value="system">System</option></select></label>
<label>Preview width<select id="width-select"><option value="604px">Forum</option><option value="375px">375 px</option><option value="320px">320 px</option></select></label>
</div>
<div class="palette-controls"><label>1 <input id="colour-1" aria-label="Member colour 1" type="color" value="#8f4b65"></label><label>2 <input id="colour-2" aria-label="Member colour 2" type="color" value="#716393"></label><label>3 <input id="colour-3" aria-label="Member colour 3" type="color" value="#3a7e81"></label><span>Preview colours only. Posts inherit member colours.</span></div>
<div class="design-intro"><div><h2 id="selected-name"></h2><p id="design-description"></p></div><div class="pager"><button id="previous" type="button" aria-label="Previous design">←</button><button id="next" type="button" aria-label="Next design">→</button></div></div>
<div class="editor-grid">
<div class="preview-column"><div class="preview-heading"><span>Live forum preview</span><span id="media-note"></span></div><div class="forum-surface"><iframe id="preview-frame" title="Selected sultana template" sandbox="allow-same-origin" scrolling="no"></iframe></div><p class="preview-caption">Ship names are prefilled and editable. Sample titles stand in for [text] in the preview; copyable code retains [url] and [text].</p></div>
<section class="fields-column" aria-label="Editable content"><h3>Make it yours</h3>
<label>Character / partner name<input id="edit-name" type="text"></label>
<label>Character / thread URL<input id="edit-url" type="text" inputmode="url"></label>
<label>Title / status text<input id="edit-text" type="text"></label>
<div id="comms-fields" hidden><label>Time<input id="edit-time" type="text"></label><label>Message direction<select id="edit-direction"><option value="received">Received</option><option value="sent">Sent</option><option value="mixed">Mixed</option></select></label></div>
<div class="image-heading"><h4>Character GIFs</h4><button id="add-image" type="button">+ Add GIF</button></div><div id="image-fields"></div><p class="field-note">Add or remove GIFs to suit the reply. Edits stay with each design while this page is open.</p>
<label>Writing / messages<textarea id="edit-body" rows="10" spellcheck="false"></textarea></label><p id="word-count"></p><p id="url-status" role="status"></p>
</section>
</div>
<section class="code-panel"><div class="code-heading"><div><h3>Ready for your post</h3><p>Copy the complete block, or download your edited snippet.</p></div><div class="code-actions"><button id="copy-button" class="primary" type="button">Copy code</button><button id="download-button" type="button">Download .txt</button></div></div><label class="code-label" for="copy-code">Complete JCink code</label><textarea id="copy-code" rows="13" readonly spellcheck="false"></textarea><p id="copy-status" role="status" aria-live="polite"></p><a id="original-snippet" href="https://github.com/lexdoescodingnow/templates/tree/main/sultana">Open original snippet on GitHub ↗</a></section>
</section>
</main>
<footer class="collection-footer"><span>Sultana / a collective of fifteen</span><span>Member colours throughout · Light &amp; dark · [dohtml] ready</span></footer>
<script>${script.replace(/<\/script/gi,'<\\/script')}</script>
</body>
</html>
`;
fs.writeFileSync(path.join(root,'sultana-collection-preview.html'),html);
console.log('Built 15 posting snippets and the standalone Sultana preview.');
