# Oats · Millhouse

Chen & Song

The 15 newer designs for current forum use: five threads, five comms and five buds.

[Forum masterpost](forum-posts/oats-forum-masterpost.txt) · [Browser preview with Copy buttons](forum-posts/oats-preview.html)

Paste the masterpost into the forum editor to display each example above its copyable code. For an individual template, open a file below and copy its entire `[dohtml]` block. Download the browser preview and open it locally for rendered examples and Copy buttons.

Examples retain full sample writing. Posting snippets use `[TEXT GOES HERE]` or `[MESSAGE GOES HERE]`. Names, links, titles and GIFs remain editable.

| Design | Type | Posting snippet |
| --- | --- | --- |
| Harvest Table | thread | [oats-harvest-table-thread-05.txt](oats/millhouse/oats-harvest-table-thread-05.txt) |
| Kilnlight Folio | thread | [oats-kilnlight-folio-thread-03.txt](oats/millhouse/oats-kilnlight-folio-thread-03.txt) |
| Millstone Letters | thread | [oats-millstone-letters-thread-01.txt](oats/millhouse/oats-millstone-letters-thread-01.txt) |
| Oatmilk Almanac | thread | [oats-oatmilk-almanac-thread-04.txt](oats/millhouse/oats-oatmilk-almanac-thread-04.txt) |
| Rolled Reverie | thread | [oats-rolled-reverie-thread-02.txt](oats/millhouse/oats-rolled-reverie-thread-02.txt) |
| Grain Frequency | comms | [oats-grain-frequency-comms-03.txt](oats/millhouse/oats-grain-frequency-comms-03.txt) |
| Milling Messenger | comms | [oats-milling-messenger-comms-02.txt](oats/millhouse/oats-milling-messenger-comms-02.txt) |
| Oatline | comms | [oats-oatline-comms-01.txt](oats/millhouse/oats-oatline-comms-01.txt) |
| Porridge Pocket | comms | [oats-porridge-pocket-comms-05.txt](oats/millhouse/oats-porridge-pocket-comms-05.txt) |
| Soak Signal | comms | [oats-soak-signal-comms-04.txt](oats/millhouse/oats-soak-signal-comms-04.txt) |
| Aftergrain | bud | [oats-aftergrain-bud-05.txt](oats/millhouse/oats-aftergrain-bud-05.txt) |
| Branlet | bud | [oats-branlet-bud-03.txt](oats/millhouse/oats-branlet-bud-03.txt) |
| Flakefold | bud | [oats-flakefold-bud-04.txt](oats/millhouse/oats-flakefold-bud-04.txt) |
| Groatlet | bud | [oats-groatlet-bud-01.txt](oats/millhouse/oats-groatlet-bud-01.txt) |
| Husk | bud | [oats-husk-bud-02.txt](oats/millhouse/oats-husk-bud-02.txt) |

## Hosted styling

The included stylesheets are copies of this set’s dependencies. Forum snippets keep their existing published stylesheet URLs in `lexdoescodingnow/templates`, so moving these files does not break existing posts. GIFs and optional fonts also require internet access. Member colours and forum light/dark modes are unchanged.

## Repository contents

`oats/` contains only this generation’s individual posting snippets and supporting CSS. `forum-posts/` contains its masterpost, numbered parts and browser preview. `designs.json` lists the included designs.
