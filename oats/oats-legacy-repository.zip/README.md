# Oats · Legacy

Chen & Song

The 15 earlier Harvest designs: five threads, five comms and five buds.

[Forum masterpost](forum-posts/oats-legacy-forum-masterpost.txt) · [Browser preview with Copy buttons](forum-posts/oats-legacy-preview.html)

Paste the masterpost into the forum editor to display each example above its copyable code. For an individual template, open a file below and copy its entire `[dohtml]` block. Download the browser preview and open it locally for rendered examples and Copy buttons.

Examples retain full sample writing. Posting snippets use `[TEXT GOES HERE]` or `[MESSAGE GOES HERE]`. Names, links, titles and GIFs remain editable.

| Design | Type | Posting snippet |
| --- | --- | --- |
| Avena Archive | thread | [oats-avena-archive-thread-01.txt](oats/oats-avena-archive-thread-01.txt) |
| Fieldwake | thread | [oats-fieldwake-thread-05.txt](oats/oats-fieldwake-thread-05.txt) |
| Husk & Honey | thread | [oats-husk-and-honey-thread-03.txt](oats/oats-husk-and-honey-thread-03.txt) |
| Kilnlight | thread | [oats-kilnlight-thread-02.txt](oats/oats-kilnlight-thread-02.txt) |
| Oatmilk Press | thread | [oats-oatmilk-press-thread-04.txt](oats/oats-oatmilk-press-thread-04.txt) |
| Groatline | comms | [oats-groatline-comms-01.txt](oats/oats-groatline-comms-01.txt) |
| Harvest Pocket | comms | [oats-harvest-pocket-comms-05.txt](oats/oats-harvest-pocket-comms-05.txt) |
| Kernel OS | comms | [oats-kernel-os-comms-03.txt](oats/oats-kernel-os-comms-03.txt) |
| Overnight Sync | comms | [oats-overnight-sync-comms-04.txt](oats/oats-overnight-sync-comms-04.txt) |
| Rolled Signal | comms | [oats-rolled-signal-comms-02.txt](oats/oats-rolled-signal-comms-02.txt) |
| Chafflet | bud | [oats-chafflet-bud-03.txt](oats/oats-chafflet-bud-03.txt) |
| Floret | bud | [oats-floret-bud-01.txt](oats/oats-floret-bud-01.txt) |
| Groat | bud | [oats-groat-bud-02.txt](oats/oats-groat-bud-02.txt) |
| Oatdrop | bud | [oats-milkdrop-bud-05.txt](oats/oats-milkdrop-bud-05.txt) |
| Twin Flakes | bud | [oats-twin-flakes-bud-04.txt](oats/oats-twin-flakes-bud-04.txt) |

## Hosted styling

The included stylesheets are copies of this set’s dependencies. Forum snippets keep their existing published stylesheet URLs in `lexdoescodingnow/templates`, so moving these files does not break existing posts. GIFs and optional fonts also require internet access. Member colours and forum light/dark modes are unchanged.

## Repository contents

`oats/` contains only this generation’s individual posting snippets and supporting CSS. `forum-posts/` contains its masterpost, numbered parts and browser preview. `designs.json` lists the included designs.
